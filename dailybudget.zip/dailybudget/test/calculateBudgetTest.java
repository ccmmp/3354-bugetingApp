import junit.framework.TestCase;
import org.junit.Test;
import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;

public class calculateBudgetTest {
    @Test
    public void budget(){
        calculateBudget calc = new calculateBudget();
        //Correct test case:
        assertEquals(1600.0,calc.budget(2000),0.001);
        //Incorrect test case:
        //assertEquals(2500.0,calc.budget(5000),0.001);
    }
}


