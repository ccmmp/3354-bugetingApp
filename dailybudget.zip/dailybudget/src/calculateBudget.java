import java.util.Scanner;
public class calculateBudget {
    //function to calculate monthly budget that you can use to spend. We are using 50 - 30 - 20 rule here
    protected double budget(double monthlyIncome){

        double needs = 0;
        double wants = 0;
        double monthlySavings = 0;
        double monthlySpending = 0;
        if(monthlyIncome>0) {
            needs = monthlyIncome * 0.5;
            wants = monthlyIncome * 0.3;
            monthlySavings = monthlyIncome * 0.2;

            monthlySpending = needs + wants;

            System.out.println("You can spend $" + monthlySpending + " this month.");
        }
        return monthlySpending;

    }

}